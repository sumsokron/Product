package com.jpfa.fivepoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FivepointApplicationTests {

    @Test
    void contextLoads() {
    }

}
