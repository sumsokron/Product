package com.jpfa.fivepoint.repository;

import com.jpfa.fivepoint.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}